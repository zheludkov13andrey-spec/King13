# Что нужно для настоящего APK KING13

## Минимум

- Android-ready проект.
- Package name: `com.andreyking.king13`
- Gradle файлы.
- AndroidManifest.
- MainActivity.
- Иконки.
- WebView или нативный frontend.
- APK build через GitHub Actions или Android Studio.

## Для Google Play

Нужен не просто APK, а AAB.

Для AAB понадобится:
- release signing key;
- privacy policy;
- screenshots;
- описание приложения;
- Data Safety form;
- проверка правил Google Play.

## Для теста на своём телефоне

Достаточно debug APK.
