# Куда нажимать в GitHub с телефона

## Создать репозиторий
1. Открой github.com
2. Нажми +
3. New repository
4. Название: KING13
5. Create repository

## Загрузить файлы
1. Открой репозиторий
2. Add file
3. Upload files
4. Выбери файлы проекта
5. Commit changes

## Добавить workflow
1. Add file
2. Create new file
3. Название файла:
`.github/workflows/build-apk.yml`
4. Вставь код workflow
5. Commit changes

## Запустить
1. Открой вкладку Actions
2. Выбери Build KING13 APK
3. Run workflow
4. Подожди завершения
5. Скачай artifact
