# KING13 v30 Ultimate Schema

Коллекции:
- users
- contacts
- chats
- messages
- groups
- channels
- channel_posts
- comments
- reactions
- cloud_files
- wallets
- transactions
- vip_subscriptions
- calls
- call_signals
- devices
- notifications
- admin_logs
- root_actions

Все названия экранов, кнопок и документация — на русском языке.
