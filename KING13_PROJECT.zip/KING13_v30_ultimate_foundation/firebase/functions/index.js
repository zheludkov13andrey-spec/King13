const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();

exports.onMessageCreate = functions.firestore.document('messages/{messageId}').onCreate(async (snap) => {
  const msg = snap.data();
  console.log('KING13 v30 push foundation:', msg.chatId);
  return null;
});

exports.onCallSignal = functions.firestore.document('call_signals/{signalId}').onCreate(async (snap) => {
  console.log('KING13 call signaling foundation:', snap.id);
  return null;
});

exports.onWalletTransaction = functions.firestore.document('transactions/{txId}').onCreate(async (snap) => {
  console.log('KING13 wallet transaction foundation:', snap.id);
  return null;
});
