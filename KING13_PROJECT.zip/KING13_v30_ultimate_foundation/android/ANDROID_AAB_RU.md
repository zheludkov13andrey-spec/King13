# KING13 v30 — Android / AAB

Package: `com.andreyking.king13`

Для финальной публикации:
1. Открыть Android Studio проект предыдущей Android-ready версии.
2. Заменить `public/` на папку из v30.
3. Выполнить Gradle Sync.
4. Generate Signed Bundle / APK.
5. Собрать `.aab`.
6. Загрузить в Google Play Console.

Важно: нужен настоящий keystore, google-services.json и privacy policy URL.
