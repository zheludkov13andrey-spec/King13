const ru='абвгдеёжзийклмнопрстуфхцчшщъыьэюя'.split(''),en='abcdefghijklmnopqrstuvwxyz'.split(''),dig='0123456789'.split(''),arr=[],BS={},BB={},KEY=[1,2,3,4,5,6,7,8,9,-9,-8,-7,-6,-5,-4,-3,-2,-1];
ru.forEach((s,i)=>arr.push([s,i+1]));en.forEach((s,i)=>arr.push([s,i+34]));dig.forEach((s,i)=>arr.push([s,i+60]));arr.push([' ',82]);arr.forEach(x=>{BS[x[0]]=x[1];BB[x[1]]=x[0]});
function enc(t){let o='',i=0;for(const r of [...(t||'')]){const c=r.toLowerCase();if(BS[c]===undefined)continue;o+=String(BS[c]+KEY[i%KEY.length]).padStart(2,'0');i++}return o}
function dec(c){const d=(c||'').replace(/\D/g,'');if(d.length%2)return'';return(d.match(/.{1,2}/g)||[]).map((b,i)=>BB[parseInt(b)-KEY[i%KEY.length]]||'�').join('')}
let chats=JSON.parse(localStorage.k30_chats||'[]'),posts=JSON.parse(localStorage.k30_posts||'[]'),files=JSON.parse(localStorage.k30_files||'[]'),crowns=Number(localStorage.k30_crowns||13),activeChat=null;
function save(){localStorage.k30_chats=JSON.stringify(chats);localStorage.k30_posts=JSON.stringify(posts);localStorage.k30_files=JSON.stringify(files);localStorage.k30_crowns=crowns}
function renderAll(){renderChats();renderPosts();renderFiles();crownsEl();labEncrypt()}
function renderChats(){chatList.innerHTML='';statChats.textContent=chats.length;if(!chats.length)chatList.innerHTML='<p>Чатов пока нет. Создай новый чат или группу.</p>';chats.forEach(c=>chatList.innerHTML+=`<div class=item onclick="KING13.openChat('${c.id}')"><div><b>${c.title}</b><p>${c.messages.at(-1)?.text||'Нет сообщений'} · ${c.type}</p></div><span>→</span></div>`)}
function newChat(){const name=prompt('Имя контакта:','King13 Support');if(!name)return;chats.push({id:Date.now().toString(),title:name,type:'личный чат',messages:[{from:'System',text:'Чат создан'}]});save();renderChats();toast('Чат создан')}
function newGroup(){const name=prompt('Название группы:','KING13 Squad');if(!name)return;chats.push({id:Date.now().toString(),title:name,type:'группа',messages:[{from:'System',text:'Группа создана'}]});save();renderChats();toast('Группа создана')}
function openChat(id){activeChat=id;chatListView.style.display='none';chatRoomView.style.display='block';const c=chats.find(x=>x.id===id);chatTitle.textContent=c.title;renderMessages()}
function closeChat(){chatRoomView.style.display='none';chatListView.style.display='block';renderChats()}
function renderMessages(){const c=chats.find(x=>x.id===activeChat);chatMessages.innerHTML='';(c?.messages||[]).forEach(m=>{const me=m.from==='Вы';chatMessages.innerHTML+=`<div class="msg ${me?'me':''}"><div>${m.cipher?dec(m.cipher):m.text}</div>${m.cipher?`<div class=cipher-mini>S13: ${m.cipher}</div>`:''}<div class=meta>${m.from} · прочитано foundation</div></div>`})}
function sendMessage(){const text=chatInput.value.trim();if(!text||!activeChat)return;const c=chats.find(x=>x.id===activeChat);c.messages.push({from:'Вы',text});chatInput.value='';save();renderMessages();renderChats()}
function sendSystem13(){const text=chatInput.value.trim();if(!text||!activeChat)return;const c=chats.find(x=>x.id===activeChat);c.messages.push({from:'Вы',text:'System13 encrypted',cipher:enc(text)});chatInput.value='';save();renderMessages();renderChats()}
function attachFile(e){const f=e.target.files?.[0];if(!f)return;const c=chats.find(x=>x.id===activeChat);if(c)c.messages.push({from:'Вы',text:'Файл: '+f.name});files.push({name:f.name,size:f.size});save();renderMessages();renderFiles();toast('Файл добавлен')}
function callFoundation(){toast('Звонки foundation: WebRTC signaling будет в backend')}
function newPost(){const text=prompt('Текст поста:','Новый пост KING13');if(!text)return;posts.unshift({id:Date.now().toString(),text,likes:13,vip:false});save();renderPosts();toast('Пост опубликован')}
function renderPosts(){postList.innerHTML='';if(!posts.length)postList.innerHTML='<p>Постов пока нет.</p>';posts.forEach(p=>postList.innerHTML+=`<div class=item><div><b>KING-канал</b><p>${p.text}</p><span class=chip>❤️ ${p.likes}</span><span class=chip>Комментарии foundation</span></div></div>`)}
function addFiles(e){[...e.target.files].forEach(f=>files.push({name:f.name,size:f.size}));save();renderFiles();toast('Файлы добавлены')}
function renderFiles(){fileList.innerHTML='';statFiles.textContent=files.length;if(!files.length)fileList.innerHTML='<p>Файлов пока нет.</p>';files.forEach(f=>fileList.innerHTML+=`<div class=item><div><b>${f.name}</b><p>${Math.round(f.size/1024)} KB · Storage foundation</p></div></div>`)}
function crownsEl(){document.getElementById('crowns').textContent=crowns;statCrowns.textContent=crowns}
function addCrowns(n){crowns+=n;save();crownsEl();walletLog.innerHTML+=`<p>Пополнение: +${n} 👑</p>`}
function giftCrowns(){if(crowns<13)return toast('Недостаточно корон');crowns-=13;save();crownsEl();walletLog.innerHTML+='<p>Подарок 13 👑 отправлен</p>'}
function buyVip(price){if(crowns<price)return toast('Недостаточно корон');crowns-=price;save();crownsEl();walletLog.innerHTML+=`<p>VIP куплен за ${price} 👑</p>`}
function saveProfile(){profileLog.textContent='Профиль и приватность сохранены локально. Firebase users/{uid} foundation готов.'}
function labEncrypt(){cipherOut.textContent=enc(plain.value);decodedOut.textContent=''}
function labDecrypt(){decodedOut.textContent=dec(cipherOut.textContent)}
window.KING13={newChat,newGroup,openChat,closeChat,sendMessage,sendSystem13,attachFile,callFoundation,newPost,addFiles,addCrowns,giftCrowns,buyVip,saveProfile,labEncrypt,labDecrypt};
renderAll();
