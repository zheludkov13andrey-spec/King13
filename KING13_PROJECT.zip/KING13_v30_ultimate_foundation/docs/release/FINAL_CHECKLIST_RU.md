# KING13 v30 Финальный чеклист

- [ ] Протестировать все экраны.
- [ ] Подключить Firebase config.
- [ ] Проверить Auth.
- [ ] Проверить Firestore rules.
- [ ] Проверить Storage upload.
- [ ] Подключить FCM.
- [ ] Собрать APK debug.
- [ ] Собрать AAB release.
- [ ] Подготовить privacy policy URL.
- [ ] Подготовить screenshots.
- [ ] Заполнить Google Play Data Safety.
- [ ] Проверить платежные правила для VIP/корон.
