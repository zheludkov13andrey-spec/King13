# KING13 Security Notes

- Firestore rules требуют аудита перед production.
- Секреты платежей нельзя хранить во frontend.
- Для настоящего E2EE нужен отдельный audited crypto слой.
- Биометрия и Secure Storage должны подключаться нативно.
- ROOT OWNER действия должны логироваться.
