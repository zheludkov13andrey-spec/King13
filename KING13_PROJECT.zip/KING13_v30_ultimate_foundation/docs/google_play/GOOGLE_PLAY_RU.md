# KING13 Google Play

Название: KING13
Package: com.andreyking.king13
Разработчик: Andrey King

Перед публикацией нужны:
- Privacy Policy URL
- Terms URL
- Data Safety form
- Content rating
- Скриншоты
- Feature graphic
- Signed AAB
- Тестирование на устройстве
