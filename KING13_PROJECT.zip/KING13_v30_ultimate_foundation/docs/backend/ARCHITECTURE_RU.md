# KING13 v30 Архитектура

## Frontend
PWA/WebView интерфейс на русском языке.

## Backend
Firebase Auth + Firestore + Storage + Cloud Functions + FCM.

## Основные модули
- Auth/users
- Contacts
- Private chats
- Groups
- Channels
- Messages
- Cloud files
- Wallet/crowns/VIP
- Calls signaling
- ROOT OWNER admin
- Notifications
