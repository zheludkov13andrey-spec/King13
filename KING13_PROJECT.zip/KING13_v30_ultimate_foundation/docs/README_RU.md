# KING13 v30 Ultimate Foundation

Разработчик: **Andrey King**

## Что вошло в финальную foundation-сборку

- Полностью русский интерфейс.
- Мессенджер: личные чаты, группы, System13, файлы.
- KING-каналы: посты, реакции, комментарии foundation.
- Облако KING13: FREE 15 GB foundation.
- Кошелёк: короны, VIP, подарки.
- ROOT OWNER panel foundation.
- Профиль и приватность.
- Настройки и безопасность foundation.
- Звонки foundation: WebRTC signaling docs/functions.
- Firebase schema/rules/functions.
- Storage rules.
- Push notifications foundation.
- Android/AAB release docs.
- Google Play checklist.
- Legal drafts.
- Security notes.

## Как открыть
Открой `public/index.html`.

## Как включить backend
1. Создать Firebase project.
2. Включить Auth.
3. Создать Firestore и Storage.
4. Вставить rules из `firebase/rules`.
5. Deploy functions.
6. Подключить Firebase SDK к frontend.
